// Parses a guide file.
//   Line 1:           version text, e.g.  V0.3 Batcoif
//   Available games:  Name-link-laptopReady-batcoifExclusive[-RATING]
//   A line that just says "soon" starts the coming-soon section:
//                     Name-description-batcoifExclusive[-RATING]
// RATING is optional and defaults to PG. R18 titles are hidden until unlocked in Settings.
const LINE = /^(.+?)\s*-\s*((?:https?:\/\/|www\.)\S*?)\s*-\s*(true|false)\s*-\s*(true|false)(?:\s*-\s*([A-Za-z0-9+]{1,8}))?$/i;
const SOON_LINE = /^(.+?)\s*-\s*(.+)\s*-\s*(true|false)(?:\s*-\s*([A-Za-z0-9+]{1,8}))?$/i;
const SOON_MARK = /^-*\s*soon\s*:?\s*-*$/i;

const truthy = (v) => v === true || String(v).trim().toLowerCase() === 'true';
const normRating = (r) => String(r || 'PG').trim().toUpperCase() || 'PG';
const isAdult = (r) => /^(R18\+?|18\+?)$/.test(r);

function normUrl(u) {
  u = String(u || '').trim();
  if (/^www\./i.test(u)) u = 'https://' + u;
  return /^https?:\/\/\S+$/i.test(u) ? u : null;
}

function parseGuide(text) {
  const t = String(text).replace(/^\uFEFF/, '').trim();
  const entries = [];
  const soon = [];
  let skipped = 0;
  let version = null;
  let lines = [];

  let parsed = null;
  try { parsed = JSON.parse(t); } catch {}
  const arr = Array.isArray(parsed) ? parsed : (parsed && Array.isArray(parsed.games) ? parsed.games : null);
  if (parsed && !Array.isArray(parsed) && typeof parsed.version === 'string') version = parsed.version.trim().slice(0, 40) || null;

  if (arr) {
    for (const it of arr) {
      if (typeof it === 'string') { lines.push(it); continue; }
      if (it && typeof it === 'object') {
        const url = normUrl(it.link || it.url);
        const name = String(it.name || '').trim();
        const rating = normRating(it.rating);
        if (name && url) entries.push({ name, url, laptop: truthy(it.laptop ?? it.laptopReady), exclusive: truthy(it.exclusive ?? it.batcoifExclusive), rating, adult: isAdult(rating) });
        else skipped++;
      }
    }
  } else {
    lines = t.split(/\r?\n/);
  }

  let inSoon = false;
  let first = true;
  for (const raw of lines) {
    let l = raw.trim();
    if (!l || l.startsWith('//') || l.startsWith('#')) continue;
    l = l.replace(/\[([^\]]*)\]\(([^)]*)\)/g, '$2');          // markdown link -> target
    l = l.replace(/^[\[\s"']+/, '').replace(/[\]\s,"']+$/, ''); // stray brackets/quotes/commas
    if (!l) continue;

    // First line = version (unless it is clearly a game line, for older guide files)
    if (first) {
      first = false;
      if (!version && !SOON_MARK.test(l) && !LINE.test(l)) { version = l.slice(0, 40); continue; }
    }

    if (SOON_MARK.test(l)) { inSoon = true; continue; }

    if (inSoon) {
      const m = SOON_LINE.exec(l);
      if (!m) { skipped++; continue; }
      const rating = normRating(m[4]);
      soon.push({ name: m[1].trim(), description: m[2].trim(), exclusive: truthy(m[3]), rating, adult: isAdult(rating) });
      continue;
    }

    const m = LINE.exec(l);
    const url = m && normUrl(m[2]);
    if (!m || !url) { skipped++; continue; }
    const rating = normRating(m[5]);
    entries.push({ name: m[1].trim(), url, laptop: truthy(m[3]), exclusive: truthy(m[4]), rating, adult: isAdult(rating) });
  }
  return { entries, soon, version, skipped };
}

module.exports = { parseGuide };
