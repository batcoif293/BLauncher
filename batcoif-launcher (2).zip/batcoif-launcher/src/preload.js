const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  list: () => ipcRenderer.invoke('games:list'),
  add: () => ipcRenderer.invoke('games:add'),
  launch: (id) => ipcRenderer.invoke('games:launch', id),
  remove: (id) => ipcRenderer.invoke('games:remove', id),
  setCover: (id) => ipcRenderer.invoke('games:setCover', id),
  clearCover: (id) => ipcRenderer.invoke('games:clearCover', id),
  showInFolder: (id) => ipcRenderer.invoke('games:showInFolder', id),
  showFolder: () => ipcRenderer.invoke('games:showFolder'),
  guideGet: () => ipcRenderer.invoke('guide:get'),
  guideImport: () => ipcRenderer.invoke('guide:import'),
  guideOpen: (url) => ipcRenderer.invoke('guide:open', url),
  guideClear: () => ipcRenderer.invoke('guide:clear'),
  settingsGet: () => ipcRenderer.invoke('settings:get'),
  settingsSet: (patch) => ipcRenderer.invoke('settings:set', patch),
  confirmAdult: () => ipcRenderer.invoke('settings:confirmAdult'),
  showDataFolder: () => ipcRenderer.invoke('data:openFolder'),
  removeMissing: () => ipcRenderer.invoke('library:removeMissing'),
  resetPlaytime: () => ipcRenderer.invoke('library:resetPlaytime'),
  onState: (cb) => ipcRenderer.on('games:state', (_e, data) => cb(data))
});
